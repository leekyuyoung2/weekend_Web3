package com.example.demo;

import com.example.demo.vo.TestVO;

public class TestMain {

	public static void main(String[] args) {
		TestVO vo = new TestVO(200,"�̼���");
//		vo.setAge(100);
//		vo.setName("ȫ�浿");
		System.out.printf("�̸�:%s  ����:%d\n", vo.getName(), vo.getAge());

	}

}
