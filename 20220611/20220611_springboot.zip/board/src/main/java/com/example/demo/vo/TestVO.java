package com.example.demo.vo;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
//@Setter
public class TestVO {
	private final int age;
	private final String name;
	
}
