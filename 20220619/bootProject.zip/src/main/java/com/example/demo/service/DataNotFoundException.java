package com.example.demo.service;

public class DataNotFoundException extends RuntimeException {

	public DataNotFoundException(String string) {
		
	}

}
