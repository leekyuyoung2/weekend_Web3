/**
 * 자바스크립트 유틸리티 함수 
 */
 
 var AJAX = {
	call:function(url,param,func){
		var callobj ={
			url:url,
			type:"post",
			data:param,
			dataType:"text",
			success:function(xhr, status, error){
				if(xhr.status == 0){
					alert("네트웍 접속이 원할하지 않습니다.");
				}else{
					console.log(xhr.responseText);
					alert("에러가 발생했습니다. 관리자에게 문의해 주세요");
				}
			},
		};
		jQuery.ajax(callobj);
	},
	test:function(){
		alert("테스트 함수 입니다.")
	}
};