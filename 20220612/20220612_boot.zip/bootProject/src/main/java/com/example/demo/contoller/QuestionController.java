package com.example.demo.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;

@Controller
@RequestMapping("/question")
public class QuestionController {
	@Autowired
	private QuestionRepository questionrepository; 
	
	@RequestMapping("/list")
//	@ResponseBody
	public String list(Model model) {
//		return "<h1>question list</h1>";
		
		List<Question> questionList = questionrepository.findAll();
		model.addAttribute("questionList", questionList);
		return "qeustionList";
	}
}
