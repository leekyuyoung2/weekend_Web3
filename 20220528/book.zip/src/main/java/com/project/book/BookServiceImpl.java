package com.project.book;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookServiceImpl implements BookService {
	@Autowired
	BookDao bookdao;

	@Override
	public String create(Map<String, Object> map) {
		int rowCount =  bookdao.insert(map);
		if(rowCount == 1)
			return map.get("book_id").toString();
		
		return null;
	}
}
