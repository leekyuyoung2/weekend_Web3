package com.project.book;

import java.util.Map;

public interface BookService {
	// 데이터 생성(책 입고)
	String create(Map<String, Object> map);
}
